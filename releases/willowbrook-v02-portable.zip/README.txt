Willowbrook v0.2 standalone preview
Requires Node.js 22+. No npm install required.
Windows: double-click start-game.cmd, then open http://localhost:4175/
macOS/Linux: node tools/serve-portable.mjs
Do not open index.html directly (file://).
This build runs server logic locally in the browser; it is not an online account service.
Save is browser/origin-specific; it is not transferred to a different computer by this ZIP.
Source and lockfile: https://github.com/herogamee/Game-Concept-Bible/tree/codex/rpgjs-v0.2
Read the source repository DEVELOPING.md to continue development.
