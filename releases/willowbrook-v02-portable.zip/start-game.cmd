@echo off
cd /d "%~dp0"
node tools\serve-portable.mjs
pause
